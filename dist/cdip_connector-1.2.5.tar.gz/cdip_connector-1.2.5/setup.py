# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cdip_connector', 'cdip_connector.core']

package_data = \
{'': ['*']}

install_requires = \
['aiohttp>=3.7.3,<4.0.0',
 'confluent-kafka>=1.9.0,<2.0.0',
 'environs>=9.3.0,<10.0.0',
 'google-cloud-pubsub>=2.5.0,<3.0.0',
 'google-cloud-storage>=1.42.0,<2.0.0',
 'opentelemetry-api>=1.14.0,<2.0.0',
 'opentelemetry-exporter-gcp-trace>=1.3.0,<2.0.0',
 'opentelemetry-instrumentation-aiohttp-client>=0.35b0,<0.36',
 'opentelemetry-instrumentation-requests>=0.35b0,<0.36',
 'opentelemetry-propagator-gcp>=1.3.0,<2.0.0',
 'opentelemetry-sdk>=1.14.0,<2.0.0',
 'pydantic>=1.7.3,<2.0.0',
 'python-dateutil>=2.8.1,<3.0.0',
 'python-json-logger>=2.0.1,<3.0.0',
 'requests>=2.25.1,<3.0.0',
 'statsd>=3.3.0,<4.0.0']

setup_kwargs = {
    'name': 'cdip-connector',
    'version': '1.2.5',
    'description': 'SMART Integrate Connector Library',
    'long_description': 'None',
    'author': 'Rohit Chaudhri',
    'author_email': 'rohitc@vulcan.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
